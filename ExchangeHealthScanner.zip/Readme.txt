1. Copy to Exchange server path like c:\project, unzip the folder
2. Open ProbeItemConfig.json to config the probe results needed and severity, probe results can be found from Event Viewer->Application and Service Logs->Microsoft->Exchange->ActiveMonitoring->ProbeResult.
3. ProbeItemConfig.json contains array of probe items, the value of ProbeType is copied from ProbeResult log, for example:Probe result (Name=OutlookMapiHttpProxyTestProbe/MSExchangeMapiFrontEndAppPool), take OutlookMapiHttpProxyTestProbe as the ProbeType;Severity has two options: high or low.
4. Run ExHealthScanner.exe as admin and wait it finished, it will generate html report file under Reports folder.
5. SMTP Email Report feature is supported but in private review stage.